'use strict';
/* ==========================================================
   TopaZ GPU Engine — WebGL 2 compositor
   All layers, effects, colour grading, transitions and blending
   run on the GPU. Source textures keep their last decoded frame,
   so the preview never flashes black while a decoder seeks.
   ========================================================== */
(() => {
const S = TZ.state;
const R = TZ.render = {};
const glc = document.createElement('canvas'); glc.width = 16; glc.height = 16;
R.canvas = glc;
let gl = null, FLOAT_OK = false, quadVAO = null;
const progs = {};
let T = null;          // render targets
let ac = 0;            // current accumulation buffer
const BLEND_ID = { normal: 0, multiply: 1, screen: 2, overlay: 3, darken: 4, lighten: 5, add: 6, difference: 7, colordodge: 8, colorburn: 9, softlight: 10, hardlight: 11, hue: 12, saturation: 13, color: 14, luminosity: 15, subtract: 16, exclusion: 17, linearlight: 18 };
R.BLEND_NAMES = { normal: 'Normalny', multiply: 'Mnożenie', screen: 'Ekran', overlay: 'Nakładka', darken: 'Ciemniej', lighten: 'Jaśniej', add: 'Dodaj', subtract: 'Odejmij', difference: 'Różnica', exclusion: 'Wykluczenie', colordodge: 'Rozjaśnianie koloru', colorburn: 'Ściemnianie koloru', softlight: 'Łagodne światło', hardlight: 'Ostre światło', linearlight: 'Światło liniowe', hue: 'Barwa', saturation: 'Nasycenie', color: 'Kolor', luminosity: 'Jasność' };
const hex2rgb = (hx) => { const nn = parseInt(String(hx || '#000').slice(1), 16); return [(nn >> 16 & 255) / 255, (nn >> 8 & 255) / 255, (nn & 255) / 255]; };
R.hex2rgb = hex2rgb;
const settings = () => TZ.settings || {};

/* ---------------- shaders ---------------- */
const VS = `#version 300 es
in vec2 a_p; uniform mat3 u_m; out vec2 v_uv;
void main(){ v_uv = a_p; vec3 q = u_m * vec3(a_p, 1.0); gl_Position = vec4(q.xy, 0.0, 1.0); }`;
const FX_HEAD = `#version 300 es
precision highp float;
in vec2 v_uv; out vec4 o;
uniform sampler2D u_tex; uniform sampler2D u_tex2;
uniform vec2 u_res; uniform float u_p[16]; uniform vec3 u_c0, u_c1, u_c2; uniform float u_time, u_lt, u_k; uniform vec4 u_box;
#define P(i) u_p[i]
vec4 T(vec2 uv){ return texture(u_tex, uv); }
vec4 T2(vec2 uv){ return texture(u_tex2, uv); }
vec4 Tz(vec2 uv){ return (uv.x<0.0||uv.y<0.0||uv.x>1.0||uv.y>1.0) ? vec4(0.0) : texture(u_tex, uv); }
vec3 unp(vec4 c){ return c.a > 0.0001 ? c.rgb / c.a : vec3(0.0); }
vec4 pre(vec3 rgb, float a){ return vec4(clamp(rgb, 0.0, 1.0) * a, a); }
float luma(vec3 c){ return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float hash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),f.x), mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0,1.0)),f.x), f.y); }
vec3 rgb2hsv(vec3 c){ vec4 K=vec4(0.0,-1.0/3.0,2.0/3.0,-1.0); vec4 p=mix(vec4(c.bg,K.wz),vec4(c.gb,K.xy),step(c.b,c.g)); vec4 q=mix(vec4(p.xyw,c.r),vec4(c.r,p.yzx),step(p.x,c.r)); float d=q.x-min(q.w,q.y); float e=1.0e-10; return vec3(abs(q.z+(q.w-q.y)/(6.0*d+e)), d/(q.x+e), q.x); }
vec3 hsv2rgb(vec3 c){ vec4 K=vec4(1.0,2.0/3.0,1.0/3.0,3.0); vec3 p=abs(fract(c.xxx+K.xyz)*6.0-K.www); return c.z*mix(K.xxx, clamp(p-K.xxx,0.0,1.0), c.y); }
float hueDist(float a, float b){ float d = abs(a-b); return min(d, 1.0-d); }
vec2 cbcr(vec3 c){ return vec2(-0.168736*c.r-0.331264*c.g+0.5*c.b, 0.5*c.r-0.418688*c.g-0.081312*c.b); }
float aspect(){ return u_res.x / u_res.y; }
void main(){ vec2 uv = v_uv; vec2 px = 1.0 / u_res; vec4 C = T(uv); vec3 X = unp(C); o = C;
`;
const FS_PLACE = `#version 300 es
precision highp float;
in vec2 v_uv; out vec4 o;
uniform sampler2D u_tex; uniform vec4 u_uvr; uniform int u_solid; uniform vec4 u_color; uniform float u_alpha; uniform int u_rot90;
void main(){ if(u_solid==1){ o=vec4(u_color.rgb*u_color.a, u_color.a)*u_alpha; return; }
  vec2 q = u_uvr.xy + v_uv*u_uvr.zw;
  if(u_rot90==1) q = vec2(q.y, 1.0-q.x); else if(u_rot90==2) q = 1.0-q; else if(u_rot90==3) q = vec2(1.0-q.y, q.x);
  o = texture(u_tex, q) * u_alpha; }`;
const FS_PRESENT = `#version 300 es
precision highp float;
in vec2 v_uv; out vec4 o; uniform sampler2D u_tex;
void main(){ vec4 c = texture(u_tex, v_uv); o = vec4(c.rgb + (1.0 - c.a) * 0.0, 1.0); }`;
const FS_COMP = `#version 300 es
precision highp float;
in vec2 v_uv; out vec4 o;
uniform sampler2D u_tex, u_dst; uniform float u_op; uniform int u_blend; uniform vec2 u_off; uniform float u_sc, u_rot, u_aspect;
uniform int u_mt; uniform float u_mp, u_ms, u_minv; uniform vec4 u_tint;
float hash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float lum(vec3 c){ return dot(c, vec3(0.3,0.59,0.11)); }
vec3 clipC(vec3 c){ float l=lum(c); float n=min(c.r,min(c.g,c.b)); float x=max(c.r,max(c.g,c.b)); if(n<0.0) c=l+(c-l)*l/(l-n+1e-5); if(x>1.0) c=l+(c-l)*(1.0-l)/(x-l+1e-5); return c; }
vec3 setLum(vec3 c, float l){ return clipC(c + (l - lum(c))); }
float sat(vec3 c){ return max(c.r,max(c.g,c.b)) - min(c.r,min(c.g,c.b)); }
vec3 setSat(vec3 c, float s){ float mx=max(c.r,max(c.g,c.b)), mn=min(c.r,min(c.g,c.b)); return mx>mn ? (c-mn)*s/(mx-mn) : vec3(0.0); }
vec3 blendf(vec3 b, vec3 s, int m){
  if(m==1) return b*s; if(m==2) return b+s-b*s; if(m==3) return mix(2.0*b*s, 1.0-2.0*(1.0-b)*(1.0-s), step(0.5,b));
  if(m==4) return min(b,s); if(m==5) return max(b,s); if(m==6) return min(b+s,1.0); if(m==7) return abs(b-s);
  if(m==8) return mix(min(b/(1.0-s+1e-5),1.0), vec3(1.0), step(1.0,s)); if(m==9) return 1.0-min((1.0-b)/(s+1e-5),1.0);
  if(m==10){ vec3 d=mix(((16.0*b-12.0)*b+4.0)*b, sqrt(b), step(0.25,b)); return mix(b-(1.0-2.0*s)*b*(1.0-b), b+(2.0*s-1.0)*(d-b), step(0.5,s)); }
  if(m==11) return mix(2.0*b*s, 1.0-2.0*(1.0-b)*(1.0-s), step(0.5,s));
  if(m==12) return setLum(setSat(s, sat(b)), lum(b)); if(m==13) return setLum(setSat(b, sat(s)), lum(b));
  if(m==14) return setLum(s, lum(b)); if(m==15) return setLum(b, lum(s));
  if(m==16) return max(b-s,0.0); if(m==17) return b+s-2.0*b*s; if(m==18) return clamp(b+2.0*s-1.0,0.0,1.0);
  return s;
}
float maskF(vec2 uv){
  if(u_mt==0) return 1.0;
  float p=u_mp, s=max(u_ms,0.0001), v=0.0, pp=p*(1.0+s);
  if(u_mt==1) v=pp-uv.x; else if(u_mt==2) v=pp-(1.0-uv.x); else if(u_mt==3) v=pp-uv.y; else if(u_mt==4) v=pp-(1.0-uv.y);
  else if(u_mt==5) v=pp-abs(uv.x-0.5)*2.0; else if(u_mt==6) v=pp-abs(uv.y-0.5)*2.0;
  else if(u_mt==7){ vec2 d=(uv-0.5)*vec2(u_aspect,1.0); v=pp-length(d)/length(vec2(u_aspect,1.0)*0.5); }
  else if(u_mt==8){ vec2 d=abs(uv-0.5)*2.0; v=pp-max(d.x,d.y); }
  else if(u_mt==9){ vec2 d=abs(uv-0.5)*2.0; v=pp-(d.x+d.y)*0.5; }
  else if(u_mt==10){ float a=atan(uv.x-0.5,-(uv.y-0.5)); a=(a<0.0?a+6.2831853:a)/6.2831853; v=pp-a; }
  else if(u_mt==11) v=pp-fract(uv.y*10.0);
  else if(u_mt==12) v=pp-hash(floor(uv*vec2(16.0,9.0)));
  else if(u_mt==13){ vec2 c=floor(uv*vec2(8.0,4.5)); float ch=mod(c.x+c.y,2.0); v=pp*2.0-(fract(uv.x*8.0)+ch); }
  else if(u_mt==14){ float band=floor(uv.y*8.0); float dd=mod(band,2.0)<1.0? uv.x : 1.0-uv.x; v=pp-dd; }
  else if(u_mt==15) return uv.x < p ? 1.0 : 0.0;
  else if(u_mt==16) return uv.x >= p ? 1.0 : 0.0;
  float m=smoothstep(0.0,s,v);
  return u_minv>0.5 ? 1.0-m : m;
}
void main(){
  vec2 uv=v_uv; vec4 dst=texture(u_dst, uv);
  vec2 q=uv-u_off-0.5; q.x*=u_aspect; float cs=cos(-u_rot), sn=sin(-u_rot); q=vec2(cs*q.x-sn*q.y, sn*q.x+cs*q.y); q.x/=u_aspect; q/=u_sc; q+=0.5;
  vec4 src=(q.x<0.0||q.y<0.0||q.x>1.0||q.y>1.0) ? vec4(0.0) : texture(u_tex, q);
  src.rgb=mix(src.rgb, u_tint.rgb*src.a, u_tint.a);
  src*=maskF(uv)*u_op;
  vec3 Cs = src.a>0.0 ? src.rgb/src.a : vec3(0.0); vec3 Cb = dst.a>0.0 ? dst.rgb/dst.a : vec3(0.0);
  vec3 B = u_blend==0 ? Cs : blendf(Cb, Cs, u_blend);
  float as=src.a, ab=dst.a;
  o = vec4((1.0-ab)*Cs*as + (1.0-as)*Cb*ab + as*ab*B, as + ab*(1.0-as));
}`;

function compile(fsSrc, name) {
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { const e = gl.getShaderInfoLog(s); console.error('Shader ' + name, e); throw new Error('Shader ' + name + ': ' + e); } return s; };
  const p = gl.createProgram();
  gl.attachShader(p, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fsSrc));
  gl.bindAttribLocation(p, 0, 'a_p');
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Link ' + name + ': ' + gl.getProgramInfoLog(p));
  const U = {}; const nU = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < nU; i++) { const inf = gl.getActiveUniform(p, i); U[inf.name.replace(/\[0\]$/, '')] = gl.getUniformLocation(p, inf.name); }
  return { p, U };
}
function fxProg(name) {
  if (progs['fx:' + name]) return progs['fx:' + name];
  const body = TZ.SHADERS[name];
  if (body == null) throw new Error('Nieznany shader ' + name);
  return (progs['fx:' + name] = compile(FX_HEAD + body + '\n}', name));
}

function init() {
  try {
    const st = settings();
    gl = glc.getContext('webgl2', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: false, depth: false, stencil: false, powerPreference: st.lowPowerGPU ? 'low-power' : 'high-performance', desynchronized: false });
    if (!gl) { R.glError = 'WebGL 2 jest niedostępny'; return false; }
    FLOAT_OK = !!gl.getExtension('EXT_color_buffer_float'); gl.getExtension('OES_texture_float_linear');
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
    quadVAO = gl.createVertexArray(); gl.bindVertexArray(quadVAO);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    progs.place = compile(FS_PLACE, 'place'); progs.present = compile(FS_PRESENT, 'present'); progs.comp = compile(FS_COMP, 'composite');
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.disable(gl.BLEND); gl.disable(gl.DEPTH_TEST);
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    R.gpuName = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
    R.maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE);
    T = null;
    return true;
  } catch (e) { console.error(e); R.glError = String(e.message || e); gl = null; return false; }
}
glc.addEventListener('webglcontextlost', e => { e.preventDefault(); gl = null; TZ.status && TZ.status('Utracono kontekst GPU – odtwarzanie…'); });
glc.addEventListener('webglcontextrestored', () => { for (const k in progs) delete progs[k]; texCache.clear(); init(); TZ.engine && TZ.engine.requestRender(); });
const ok = init();
R.glOK = () => !!gl;

/* ---------------- render targets ---------------- */
function makeTarget(w, h, hq) {
  const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
  if (hq && FLOAT_OK) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.HALF_FLOAT, null);
  else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  const fbo = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  return { tex, fbo, w, h };
}
function freeTarget(t) { gl.deleteTexture(t.tex); gl.deleteFramebuffer(t.fbo); }
function ensure(W, H) {
  const hq = !!settings().hq16;
  if (glc.width !== W || glc.height !== H) { glc.width = W; glc.height = H; }
  if (T && T.w === W && T.h === H && T.hq === hq) return;
  if (T) [...T.acc, ...T.lay, T.aux].forEach(freeTarget);
  T = { w: W, h: H, hq, acc: [makeTarget(W, H, hq), makeTarget(W, H, hq)], lay: [makeTarget(W, H, hq), makeTarget(W, H, hq)], aux: makeTarget(W, H, hq) };
}

/* ---------------- source textures ---------------- */
const texCache = new Map();
function texEntry(key) {
  let e = texCache.get(key);
  if (!e) { const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    e = { tex, w: 0, h: 0, ok: false, used: performance.now() }; texCache.set(key, e); }
  e.used = performance.now();
  return e;
}
R.stats = { uploads: 0, fails: 0, nulls: 0, lastErr: '' };
function upload(e, src, w, h, mip) {
  gl.bindTexture(gl.TEXTURE_2D, e.tex);
  try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src); R.stats.uploads++; }
  catch (er) { R.stats.fails++; R.stats.lastErr = String(er); return false; }
  e.w = w; e.h = h; e.ok = true;
  if (mip) { gl.generateMipmap(gl.TEXTURE_2D); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); e.mip = true; }
  else if (e.mip) { gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); e.mip = false; }
  return true;
}
// upload the current frame of a (pre-rolled) element so the clip never starts black
R.primeClip = (clip, el) => {
  if (!gl || !el || el.readyState < 2 || el.seeking) return;
  const e = texEntry('c:' + clip.id);
  if (e.ok && e.lastT === el.currentTime) return;
  if (upload(e, el, el.videoWidth, el.videoHeight, false)) { e.lastT = el.currentTime; e.mipWanted = false; }
};
R.releaseTexture = (key) => { const e = texCache.get(key); if (e && gl) { gl.deleteTexture(e.tex); texCache.delete(key); } };
setInterval(() => { if (!gl) return; const now = performance.now(); for (const [k, e] of texCache) if (now - e.used > 60000 && !k.startsWith('i:')) { gl.deleteTexture(e.tex); texCache.delete(k); } }, 20000);

/* ---------------- text rendering (Canvas 2D -> texture) ---------------- */
const mk = (w, hh) => { const c = document.createElement('canvas'); c.width = w; c.height = hh; return c; };
const tx1 = mk(16, 16).getContext('2d');
const textCache = new Map();
R.textCanvas = (clip, lt) => {
  const Tt = clip.text || TZ.defaultText();
  let content = String(Tt.content || '');
  if (Tt.anim === 'typewriter') content = content.slice(0, Math.max(0, Math.floor(lt * 18)));
  const key = JSON.stringify(Tt) + '|' + content;
  const hit = textCache.get(clip.id);
  if (hit && hit.key === key) return hit.c;
  const font = `${Tt.italic ? 'italic ' : ''}${Tt.bold ? '700' : '400'} ${Tt.size}px "${Tt.font}", "Segoe UI", Arial, sans-serif`;
  tx1.font = font; try { tx1.letterSpacing = (Tt.tracking || 0) + 'px'; } catch (e) {}
  const lines = content.split('\n'), full = String(Tt.content || '').split('\n');
  const maxW = Math.max(10, ...full.map(s => tx1.measureText(s || ' ').width));
  const lh = Tt.size * (Tt.lineHeight || 1.15), pad = Tt.bg ? (Tt.bgPad || 0) : 0;
  const ex = Math.ceil((Tt.stroke || 0) + (Tt.shadow ? (Tt.shadowBlur || 0) + 8 : 0)) + 4;
  const w = Math.ceil(maxW + pad * 2 + ex * 2), hh = Math.ceil(full.length * lh + pad * 2 + ex * 2);
  const c = mk(Math.max(1, w), Math.max(1, hh)); const x = c.getContext('2d');
  x.font = font; try { x.letterSpacing = (Tt.tracking || 0) + 'px'; } catch (e) {}
  if (Tt.bg) { x.save(); x.globalAlpha = (Tt.bgOpacity == null ? 100 : Tt.bgOpacity) / 100; x.fillStyle = Tt.bgColor; if (Tt.shadow) { x.shadowColor = 'rgba(0,0,0,.5)'; x.shadowBlur = (Tt.shadowBlur || 0) * .6; x.shadowOffsetY = 3; } x.beginPath(); x.roundRect(ex, ex, w - ex * 2, hh - ex * 2, Tt.bgRadius || 0); x.fill(); x.restore(); }
  x.textBaseline = 'middle'; x.textAlign = Tt.align === 'left' ? 'left' : Tt.align === 'right' ? 'right' : 'center';
  const ax = Tt.align === 'left' ? ex + pad : Tt.align === 'right' ? w - ex - pad : w / 2;
  lines.forEach((s, i) => {
    const y = ex + pad + lh * i + lh / 2;
    if (Tt.shadow && !Tt.bg) { x.shadowColor = Tt.shadowColor || '#000'; x.shadowBlur = Tt.shadowBlur || 0; x.shadowOffsetY = Math.round(Tt.size / 30); }
    if (Tt.stroke > 0) { x.lineJoin = 'round'; x.lineWidth = Tt.stroke * 2; x.strokeStyle = Tt.strokeColor; x.strokeText(s, ax, y); x.shadowColor = 'transparent'; }
    x.fillStyle = Tt.color; x.fillText(s, ax, y); x.shadowColor = 'transparent';
  });
  textCache.set(clip.id, { key, c });
  return c;
};
R.clearTextCache = (id) => { if (id) textCache.delete(id); else textCache.clear(); };

/* ---------------- sources ---------------- */
// geometry-only info (also used by panels / hit testing)
R.sourceFor = (clip, t) => {
  if (clip.type === 'text') { const c = R.textCanvas(clip, t - clip.start); return { w: c.width, h: c.height, fit: 1 }; }
  if (clip.type === 'color' || clip.type === 'adjust') return { w: S.seq.width, h: S.seq.height, fit: 1 };
  const m = TZ.mediaById(clip.mediaId);
  if (!m || m.missing || !m.width) return { w: S.seq.width, h: S.seq.height, fit: 1, missing: !m || m.missing };
  return { w: m.width, h: m.height, fit: Math.min(S.seq.width / m.width, S.seq.height / m.height) };
};
// returns { tex } bound/updated for this frame or null
function sourceTexture(clip, t, opts, downscale) {
  const lt = t - clip.start;
  if (clip.type === 'text') {
    const c = R.textCanvas(clip, lt); const e = texEntry('t:' + clip.id);
    if (e.src !== c) { upload(e, c, c.width, c.height, false); e.src = c; }
    return e;
  }
  const m = TZ.mediaById(clip.mediaId);
  if (!m || m.missing) return null;
  if (clip.type === 'image') {
    if (!m.img) return null;
    const e = texEntry('i:' + m.id);
    const mip = downscale && settings().hqScale !== false;
    if (!e.ok || (mip && !e.mip)) upload(e, m.img, m.width, m.height, mip);
    return e;
  }
  if (clip.type === 'video') {
    let frame = opts.sources && opts.sources.get(clip.id), rot = 0;
    if (frame && frame.frame) { rot = frame.rot || 0; frame = frame.frame; }
    const mip = downscale && settings().hqScale !== false;
    if (frame) { const e = texEntry('f:' + clip.id); upload(e, frame, frame.displayWidth, frame.displayHeight, mip); e.rot = rot; return e; }
    const el = TZ.engine.videoEl(clip);
    const e = texEntry('c:' + clip.id);      // per-clip texture keeps the last good frame
    if (!e.ok && m.strip && m.strip.length) {  // placeholder from thumbnail strip until the decoder delivers
      const st = E_src(clip, t); let best = m.strip[0];
      for (const s2 of m.strip) if (Math.abs(s2.t - st) < Math.abs(best.t - st)) best = s2;
      upload(e, best.c, best.c.width, best.c.height, false); e.lastT = -1;
    }
    if (!el) return e.ok ? e : null;
    const pt = (clip.effects || []).find(f => f.id === 'postime' && f.enabled !== false);
    const hold = pt && e.ok && Math.floor(lt * pt.p.fps) === e.holdStep;
    if (el.readyState >= 2 && !el.seeking && !hold) {
      if (!e.ok || !el.paused || e.lastT !== el.currentTime || e.mipWanted !== mip) {
        if (upload(e, el, el.videoWidth, el.videoHeight, mip)) { e.lastT = el.currentTime; e.mipWanted = mip; if (pt) e.holdStep = Math.floor(lt * pt.p.fps); }
      }
    }
    return e.ok ? e : null;
  }
  return null;
}

const E_src = (clip, t) => TZ.engine.srcTime(clip, t);
/* ---------------- geometry ---------------- */
R.clipGeom = (clip, t, srcInfo) => {
  const lt = t - clip.start;
  const si = srcInfo || R.sourceFor(clip, t);
  if (!si) return null;
  const P = k => TZ.propAt(clip, k, lt);
  const sc = P('scale') / 100 * si.fit;
  const cl = P('cropL') / 100, cr = P('cropR') / 100, ct = P('cropT') / 100, cb = P('cropB') / 100;
  const bw = si.w * sc, bh = si.h * sc;
  return { cx: P('posX'), cy: P('posY'), rot: P('rotation') * Math.PI / 180, x0: -bw / 2 + bw * cl, y0: -bh / 2 + bh * ct, w: bw * Math.max(0, 1 - cl - cr), h: bh * Math.max(0, 1 - ct - cb), bw, bh, cl, cr, ct, cb, si, sc };
};
R.clipWindow = (c, clips) => {
  clips = clips || S.seq.clips.filter(x => x.track === c.track && x.enabled !== false);
  let s = c.start, e = c.start + c.dur;
  if (c.transIn && clips.some(x => x !== c && Math.abs(x.start + x.dur - c.start) < 1e-3)) s -= c.transIn.dur / 2;
  const next = clips.find(x => x !== c && Math.abs(c.start + c.dur - x.start) < 1e-3);
  if (next && next.transIn) e += next.transIn.dur / 2;
  return [s, e];
};
const noise1 = (x) => { const i = Math.floor(x), f = x - i; const r = nn => { const s = Math.sin(nn * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); }; const u = f * f * (3 - 2 * f); return r(i) * (1 - u) + r(i + 1) * u; };
// 3x3 column-major helpers
const mul = (a, b) => { const o = new Float32Array(9); for (let c = 0; c < 3; c++) for (let r = 0; r < 3; r++) o[c * 3 + r] = a[r] * b[c * 3] + a[3 + r] * b[c * 3 + 1] + a[6 + r] * b[c * 3 + 2]; return o; };
const mT = (x, y) => new Float32Array([1, 0, 0, 0, 1, 0, x, y, 1]);
const mS = (x, y) => new Float32Array([x, 0, 0, 0, y, 0, 0, 0, 1]);
const mR = (a) => { const c = Math.cos(a), s = Math.sin(a); return new Float32Array([c, s, 0, -s, c, 0, 0, 0, 1]); };
const FSM = new Float32Array([2, 0, 0, 0, 2, 0, -1, -1, 1]);
const FSM_FLIP = new Float32Array([2, 0, 0, 0, -2, 0, -1, 1, 1]);

/* ---------------- drawing primitives ---------------- */
function bindTarget(t) { gl.bindFramebuffer(gl.FRAMEBUFFER, t ? t.fbo : null); gl.viewport(0, 0, t ? t.w : glc.width, t ? t.h : glc.height); }
function drawQuad() { gl.bindVertexArray(quadVAO); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); }
function setFX(prog, p, o, W, H, lt, k, box) {
  const U = prog.U;
  const arr = new Float32Array(16); if (p) for (let i = 0; i < p.length && i < 16; i++) arr[i] = +p[i] || 0;
  if (U.u_p) gl.uniform1fv(U.u_p, arr);
  if (U.u_res) gl.uniform2f(U.u_res, W, H);
  if (U.u_c0) gl.uniform3fv(U.u_c0, o && o.c0 ? (Array.isArray(o.c0) ? o.c0 : hex2rgb(o.c0)) : [0, 0, 0]);
  if (U.u_c1) gl.uniform3fv(U.u_c1, o && o.c1 ? (Array.isArray(o.c1) ? o.c1 : hex2rgb(o.c1)) : [0, 0, 0]);
  if (U.u_c2) gl.uniform3fv(U.u_c2, o && o.c2 ? (Array.isArray(o.c2) ? o.c2 : hex2rgb(o.c2)) : [0, 0, 0]);
  if (U.u_time) gl.uniform1f(U.u_time, S.playhead || 0);
  if (U.u_lt) gl.uniform1f(U.u_lt, lt || 0);
  if (U.u_k) gl.uniform1f(U.u_k, k || 1);
  if (U.u_box) gl.uniform4fv(U.u_box, box || [0, 0, 1, 1]);
  if (U.u_m) gl.uniformMatrix3fv(U.u_m, false, FSM);
  if (U.u_tex) gl.uniform1i(U.u_tex, 0);
  if (U.u_tex2) gl.uniform1i(U.u_tex2, 1);
}
// effect pipeline context
function makeG(W, H, k, lt, box) {
  const G = {
    W, H, k, lt, box, cur: 0,
    tex() { return T.lay[G.cur].tex; },
    pass(name, p, o = {}) {
      const prog = fxProg(name);
      const dst = T.lay[1 - G.cur];
      bindTarget(dst); gl.useProgram(prog.p);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.lay[G.cur].tex);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, o.aux ? T.aux.tex : T.lay[G.cur].tex);
      setFX(prog, p, o, W, H, lt, k, box);
      drawQuad();
      gl.activeTexture(gl.TEXTURE0);
      G.cur = 1 - G.cur;
    },
    saveAux() {
      const prog = fxProg('copy'); bindTarget(T.aux); gl.useProgram(prog.p);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.lay[G.cur].tex);
      setFX(prog, null, null, W, H, lt, k, box); drawQuad();
    }
  };
  return G;
}
function paramArray(def, P) {
  const nums = [], cols = [];
  for (const p of def.params) {
    const v = P[p.k];
    if (p.type === 'color') cols.push(v);
    else if (p.type === 'check') nums.push(v ? 1 : 0);
    else nums.push(+v || 0);
  }
  return { nums, cols };
}
function lumetriP(l) {
  const look = TZ.LOOKS.find(x => x.id === l.look);
  const la = look && look.l ? (l.lookAmt == null ? 1 : l.lookAmt / 100) : 0;
  const g = (k) => (l[k] || 0) + (la && look.l[k] != null ? look.l[k] * la : 0);
  const sat = (l.saturation == null ? 100 : l.saturation) + (la && look.l.saturation != null ? (look.l.saturation - 100) * la : 0);
  const sh = la && look.l.sh ? look.l.sh.map(v => v * la) : [0, 0, 0];
  const hi = la && look.l.hi ? look.l.hi.map(v => v * la) : [0, 0, 0];
  return { p: [g('exposure'), g('contrast') / 100, g('highlights') / 100, g('shadows') / 100, g('whites') / 100, g('blacks') / 100, g('temperature') / 100, g('tint') / 100, sat / 100, g('vibrance') / 100, g('faded') / 100, (l.sharpen || 0) / 100 * 0.8, -(l.vigAmount || 0) / 100, 0.15 + (l.vigMid == null ? 50 : l.vigMid) / 100 * 0.75, 0.03 + (l.vigFeather == null ? 50 : l.vigFeather) / 100 * 0.9], c0: sh, c1: hi };
}
R.lumetriP = lumetriP;

/* build the layer for a clip; returns G (layer texture = G.tex()) or null */
function buildLayer(clip, t, W, H, k, opts, extra) {
  const lt = t - clip.start;
  const fx = (clip.effects || []).filter(e => e.enabled !== false);
  const fxOn = id => fx.find(e => e.id === id);
  let box = [0, 0, 1, 1];
  bindTarget(T.lay[0]); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
  if (clip.type === 'adjust') {
    const prog = fxProg('copy'); gl.useProgram(prog.p);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.acc[ac].tex);
    setFX(prog, null, null, W, H, lt, k, box); drawQuad();
  } else {
    const si = R.sourceFor(clip, t);
    const g = R.clipGeom(clip, t, si);
    if (!g) return null;
    let sx = 1, sy = 1, dx = 0, dy = 0, dr = 0;
    if (fxOn('hflip')) sx = -1; if (fxOn('vflip')) sy = -1;
    const sh = fxOn('shake');
    if (sh) { const P = TZ.fxParams(sh, lt); const a = P.amount / 100, sp = P.sp || 1; dx = (noise1(lt * 9 * sp) - .5) * 60 * a; dy = (noise1(lt * 9 * sp + 50) - .5) * 60 * a; dr = (noise1(lt * 7 * sp + 99) - .5) * 0.06 * a; }
    let alphaMul = 1, ty = 0, smul = 1;
    if (clip.type === 'text' && clip.text && clip.text.anim && clip.text.anim !== 'none') {
      const A = clip.text.anim, inP = TZ.clamp(lt / 0.6, 0, 1), outP = TZ.clamp((clip.dur - lt) / 0.4, 0, 1), e = 1 - Math.pow(1 - inP, 3);
      if (A === 'fade') alphaMul = Math.min(inP, outP);
      else if (A === 'slideup') { alphaMul = Math.min(inP, outP); ty = (1 - e) * 90; }
      else if (A === 'pop') { const c1 = 1.70158, c3 = c1 + 1, b = 1 + c3 * Math.pow(inP - 1, 3) + c1 * Math.pow(inP - 1, 2); smul = 0.3 + 0.7 * b; alphaMul = Math.min(1, inP * 3) * outP; }
    }
    const M2 = mul(new Float32Array([2 / W, 0, 0, 0, 2 / H, 0, -1, -1, 1]), mul(mS(k, k), mul(mT(g.cx + dx, g.cy + dy + ty), mul(mR(g.rot + dr), mul(mS(sx * smul, sy * smul), mul(mT(g.x0, g.y0), mS(g.w, g.h)))))));
    const prog = progs.place; gl.useProgram(prog.p);
    gl.uniformMatrix3fv(prog.U.u_m, false, M2);
    gl.uniform1f(prog.U.u_alpha, alphaMul);
    if (clip.type === 'color' || si.missing) {
      gl.uniform1i(prog.U.u_solid, 1);
      const c = si.missing ? [0.45, 0.05, 0.05] : hex2rgb(clip.color || '#000000');
      gl.uniform4f(prog.U.u_color, c[0], c[1], c[2], 1);
    } else {
      const downscale = g.sc * k < 0.66;
      const e = sourceTexture(clip, t, opts, downscale);
      if (!e) { R.stats.nulls++; return null; }
      gl.uniform1i(prog.U.u_solid, 0);
      gl.uniform1i(prog.U.u_rot90, e.rot ? ((Math.round(e.rot / 90) % 4) + 4) % 4 : 0);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, e.tex); gl.uniform1i(prog.U.u_tex, 0);
      gl.uniform4f(prog.U.u_uvr, g.cl, g.ct, Math.max(0, 1 - g.cl - g.cr), Math.max(0, 1 - g.ct - g.cb));
    }
    drawQuad();
    // bbox for box-aware effects
    const pts = [[g.x0, g.y0], [g.x0 + g.w, g.y0], [g.x0, g.y0 + g.h], [g.x0 + g.w, g.y0 + g.h]].map(([x, y]) => {
      const c = Math.cos(g.rot), s = Math.sin(g.rot); return [(g.cx + x * c - y * s) * k / W, (g.cy + x * s + y * c) * k / H];
    });
    box = [Math.min(...pts.map(p => p[0])), Math.min(...pts.map(p => p[1])), Math.max(...pts.map(p => p[0])), Math.max(...pts.map(p => p[1]))];
  }
  const G = makeG(W, H, k, lt, box);
  for (const f of fx) {
    const def = TZ.fxDef(f.id); if (!def || def.audio || def.place || def.time) continue;
    const P = TZ.fxParams(f, lt);
    try {
      if (def.run) def.run(G, P);
      else { const { nums, cols } = paramArray(def, P); G.pass(def.id, nums, { c0: cols[0], c1: cols[1], c2: cols[2] }); }
    } catch (e) { console.warn('efekt', f.id, e); }
  }
  if (clip.lumetri && !TZ.lumetriIsDefault(clip.lumetri)) { const L = lumetriP(clip.lumetri); G.pass('lumetri', L.p, { c0: L.c0, c1: L.c1 }); }
  if (extra) {
    if (extra.blur > 0.5) { G.pass('blur1d', [extra.blur, 1, 0]); G.pass('blur1d', [extra.blur, 0, 1]); }
    if (extra.dirblur) G.pass('dirblur', [extra.dirblur.a, extra.dirblur.len]);
    if (extra.glitch) G.pass('glitch', [extra.glitch * 100, 24]);
  }
  return G;
}
function composite(layerTex, W, H, clip, o = {}) {
  const prog = progs.comp; const dst = T.acc[1 - ac];
  bindTarget(dst); gl.useProgram(prog.p);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, layerTex); gl.uniform1i(prog.U.u_tex, 0);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, T.acc[ac].tex); gl.uniform1i(prog.U.u_dst, 1);
  gl.activeTexture(gl.TEXTURE0);
  const U = prog.U;
  gl.uniformMatrix3fv(U.u_m, false, FSM);
  const lt = S.playhead - clip.start;
  const op = TZ.clamp((o.time != null ? TZ.propAt(clip, 'opacity', o.time - clip.start) : TZ.propAt(clip, 'opacity', lt)) / 100, 0, 1) * (o.alpha == null ? 1 : o.alpha);
  gl.uniform1f(U.u_op, op);
  gl.uniform1i(U.u_blend, clip.type === 'adjust' ? 0 : (BLEND_ID[clip.props.blend] || 0));
  gl.uniform2f(U.u_off, o.dx || 0, o.dy || 0);
  gl.uniform1f(U.u_sc, o.scale == null ? 1 : Math.max(0.0001, o.scale));
  gl.uniform1f(U.u_rot, o.rot || 0);
  gl.uniform1f(U.u_aspect, W / H);
  const m = o.mask || {};
  gl.uniform1i(U.u_mt, m.type || 0); gl.uniform1f(U.u_mp, m.p || 0); gl.uniform1f(U.u_ms, m.soft == null ? 0.04 : m.soft); gl.uniform1f(U.u_minv, m.inv ? 1 : 0);
  gl.uniform4fv(U.u_tint, o.tint || [0, 0, 0, 0]);
  drawQuad();
  ac = 1 - ac;
}
function drawClip(clip, t, W, H, k, opts, o = {}) {
  const extra = (o.blur || o.dirblur || o.glitch) ? { blur: o.blur, dirblur: o.dirblur, glitch: o.glitch } : null;
  const G = buildLayer(clip, t, W, H, k, opts, extra);
  if (!G) return;
  const oo = Object.assign({}, o, { time: t });
  if (o.dark) oo.tint = [0, 0, 0, TZ.clamp(o.dark, 0, 1)];
  if (o.light) oo.tint = [1, 1, 1, TZ.clamp(o.light, 0, 1)];
  composite(G.tex(), W, H, clip, oo);
}

/* ---------------- transitions ---------------- */
const ease = p => p * p * (3 - 2 * p);
const MASKS = { wipe: 1, wipe_r: 2, wipe_d: 3, wipe_u: 4, barn: 5, iris: 7, irisbox: 8, irisdiamond: 9, clock: 10, blindsT: 11, blocksT: 12, checkerT: 13, band: 14 };
function drawPair(a, b, p, type, t, W, H, k, opts) {
  const D = (c, o) => c && drawClip(c, t, W, H, k, opts, o || {});
  const e = ease(p);
  if (MASKS[type]) {
    const mt = MASKS[type];
    if (a && b) { D(a); D(b, { mask: { type: mt, p: e, soft: 0.04 } }); }
    else if (b) D(b, { mask: { type: mt, p: e, soft: 0.04 } });
    else D(a, { mask: { type: mt, p: e, soft: 0.04, inv: 1 } });
    return;
  }
  const slide = { slide_l: [1, 0], slide_r: [-1, 0], slide_u: [0, 1], slide_d: [0, -1] }[type];
  if (slide) { D(a); if (b) D(b, { dx: slide[0] * (1 - e), dy: slide[1] * (1 - e) }); else D(a, { alpha: 0 }); if (!b && a) { /* fade one-sided */ } return; }
  const push = { push_l: [-1, 0], push_r: [1, 0], push_u: [0, -1], push_d: [0, 1] }[type];
  if (push) { D(a, { dx: push[0] * e, dy: push[1] * e }); if (b) D(b, { dx: -push[0] * (1 - e), dy: -push[1] * (1 - e) }); return; }
  switch (type) {
    case 'dipblack': case 'dipwhite': {
      const key = type === 'dipblack' ? 'dark' : 'light';
      if (a && b) { if (p < 0.5) D(a, { [key]: p * 2 }); else D(b, { [key]: (1 - p) * 2 }); }
      else if (b) D(b, { [key]: 1 - p }); else D(a, { [key]: p });
      break;
    }
    case 'flash': {
      if (a && b) { if (p < 0.5) D(a, { light: Math.pow(p * 2, 2) }); else D(b, { light: Math.pow((1 - p) * 2, 2) }); }
      else if (b) D(b, { light: Math.pow(1 - p, 2) }); else D(a, { light: p * p });
      break;
    }
    case 'blurdis': { const bl = Math.sin(p * Math.PI) * 30 * k; if (a) D(a, { alpha: b ? 1 : 1 - p, blur: bl }); if (b) D(b, { alpha: p, blur: bl }); break; }
    case 'additive': if (a) D(a, { alpha: b ? 1 : 1 - p, light: Math.sin(p * Math.PI) * 0.35 }); if (b) D(b, { alpha: p, light: Math.sin(p * Math.PI) * 0.35 }); break;
    case 'filmdis': if (a) D(a, { alpha: b ? 1 : 1 - p }); if (b) D(b, { alpha: Math.pow(p, 1.6) }); break;
    case 'whip': { const len = Math.sin(p * Math.PI) * W * 0.12; D(a, { dx: -e, dirblur: { a: 0, len } }); if (b) D(b, { dx: 1 - e, dirblur: { a: 0, len } }); break; }
    case 'split': if (b) D(b); D(a, { dx: -e / 2, mask: { type: 15, p: 0.5 - e / 2 } }); D(a, { dx: e / 2, mask: { type: 16, p: 0.5 + e / 2 } }); break;
    case 'inset': D(a); if (b) D(b, { scale: Math.max(e, 0.001), dx: -(1 - e) / 2, dy: -(1 - e) / 2 }); break;
    case 'zoom': D(a); if (b) D(b, { scale: Math.max(e, 0.001), alpha: Math.min(1, p * 1.5) }); else D(a, { alpha: 0 }); break;
    case 'zoomout': if (b) D(b); D(a, { scale: 1 + e, alpha: 1 - p }); break;
    case 'crosszoom': if (p < 0.5) { const q = p * 2; D(a, { scale: 1 + q * q * 1.5, blur: q * 30 * k }); } else { const q = (1 - p) * 2; if (b) D(b, { scale: 1 + q * q * 1.5, blur: q * 30 * k }); } break;
    case 'spin': D(a, { scale: 1 + e * 0.6, alpha: 1 - p, rot: e * 0.5 }); if (b) D(b, { scale: 0.4 + 0.6 * e, rot: (1 - e) * -0.6, alpha: p }); break;
    case 'glitchT': { const g = Math.sin(p * Math.PI); if (p < 0.5) D(a, { glitch: g }); else if (b) D(b, { glitch: g }); else D(a, { glitch: g, alpha: 1 - p }); break; }
    case 'lightleakT': { const L = Math.sin(p * Math.PI) * 0.55; if (a) D(a, { alpha: b ? 1 : 1 - p, tint: [1, 0.62, 0.3, L] }); if (b) D(b, { alpha: p, tint: [1, 0.62, 0.3, L] }); break; }
    default: // cross
      if (a && b) { D(a); D(b, { alpha: p }); } else if (b) D(b, { alpha: p }); else if (a) D(a, { alpha: 1 - p });
  }
}
function drawTrack(trackId, t, W, H, k, opts) {
  const clips = S.seq.clips.filter(c => c.track === trackId && c.enabled !== false).sort((a, b) => a.start - b.start);
  if (!clips.length) return;
  for (const c of clips) {
    if (c.transIn) {
      const d = c.transIn.dur;
      const prev = clips.find(x => x !== c && Math.abs(x.start + x.dur - c.start) < 1e-3);
      if (prev) { const s = c.start - d / 2; if (t >= s && t < s + d) { drawPair(prev, c, (t - s) / d, c.transIn.type, t, W, H, k, opts); return; } }
      else if (t >= c.start && t < c.start + d) { drawPair(null, c, (t - c.start) / d, c.transIn.type, t, W, H, k, opts); return; }
    }
    if (c.transOut) {
      const d = c.transOut.dur, end = c.start + c.dur;
      const next = clips.find(x => x !== c && Math.abs(end - x.start) < 1e-3);
      if (!(next && next.transIn) && t >= end - d && t < end) { drawPair(c, next || null, (t - (end - d)) / d, c.transOut.type, t, W, H, k, opts); return; }
    }
  }
  const c = clips.find(c => t >= c.start && t < c.start + c.dur);
  if (c) drawClip(c, t, W, H, k, opts, {});
}

/* ---------------- main entry ---------------- */
R.renderFrame = (t, ctx2d, W, H, opts = {}) => {
  if (!gl) { if (ctx2d) { ctx2d.fillStyle = '#300'; ctx2d.fillRect(0, 0, ctx2d.canvas.width, ctx2d.canvas.height); } return null; }
  W = Math.max(2, Math.round(W)); H = Math.max(2, Math.round(H));
  ensure(W, H);
  const k = W / S.seq.width;
  ac = 0;
  bindTarget(T.acc[0]); gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT);
  const vt = TZ.videoTracks().slice().reverse();
  for (const tr of vt) { if (!tr.hidden) { try { drawTrack(tr.id, t, W, H, k, opts); } catch (e) { console.error(e); } } }
  // present
  bindTarget(null);
  const pp = progs.present; gl.useProgram(pp.p);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.acc[ac].tex); gl.uniform1i(pp.U.u_tex, 0);
  gl.uniformMatrix3fv(pp.U.u_m, false, FSM_FLIP);
  drawQuad();
  if (ctx2d) { ctx2d.drawImage(glc, 0, 0, ctx2d.canvas.width, ctx2d.canvas.height); }
  return glc;
};
// read back current frame (RGBA top-down) for the native C++ engine
R.readPixels = (W, H, out) => {
  const buf = out || new Uint8Array(W * H * 4);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, buf);
  // flip rows (GL origin bottom-left)
  const row = W * 4, tmp = new Uint8Array(row);
  for (let y = 0; y < (H >> 1); y++) { const a = y * row, b = (H - 1 - y) * row; tmp.set(buf.subarray(a, a + row)); buf.copyWithin(a, b, b + row); buf.set(tmp, b); }
  return buf;
};

/* hit testing in sequence coordinates */
R.hitTest = (t, x, y) => {
  for (const tr of TZ.videoTracks()) {
    if (tr.hidden || tr.locked) continue;
    const c = S.seq.clips.find(c => c.track === tr.id && c.enabled !== false && t >= c.start && t < c.start + c.dur && c.type !== 'adjust');
    if (!c) continue;
    const g = R.clipGeom(c, t); if (!g) continue;
    const dx = x - g.cx, dy = y - g.cy, cs = Math.cos(-g.rot), sn = Math.sin(-g.rot);
    const lx2 = dx * cs - dy * sn, ly2 = dx * sn + dy * cs;
    if (lx2 >= g.x0 && lx2 <= g.x0 + g.w && ly2 >= g.y0 && ly2 <= g.y0 + g.h) return c;
  }
  return null;
};

/* look preview: lumetri applied to a small canvas */
let prevT = null;
R.lookPreview = (srcCanvas, lookId, out) => {
  const x = out.getContext('2d');
  x.drawImage(srcCanvas, 0, 0, out.width, out.height);
  if (!gl || lookId === 'none') return;
  const W = out.width, H = out.height;
  if (!prevT || prevT.w !== W || prevT.h !== H) { if (prevT) [prevT.a, prevT.b].forEach(freeTarget); prevT = { w: W, h: H, a: makeTarget(W, H, false), b: makeTarget(W, H, false) }; }
  const e = texEntry('preview'); upload(e, out, W, H, false);
  const l = TZ.defaultLumetri(); l.look = lookId; const L = lumetriP(l);
  const prog = fxProg('lumetri');
  if (glc.width !== W || glc.height !== H) { glc.width = W; glc.height = H; }
  bindTarget(prevT.a); gl.useProgram(prog.p);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, e.tex);
  setFX(prog, L.p, { c0: L.c0, c1: L.c1 }, W, H, 0, 1, [0, 0, 1, 1]); drawQuad();
  bindTarget(null); gl.viewport(0, 0, W, H);
  const pp = progs.present; gl.useProgram(pp.p); gl.bindTexture(gl.TEXTURE_2D, prevT.a.tex); gl.uniformMatrix3fv(pp.U.u_m, false, FSM_FLIP); drawQuad();
  x.clearRect(0, 0, W, H); x.drawImage(glc, 0, 0, W, H, 0, 0, W, H);
  if (T) { glc.width = T.w; glc.height = T.h; }
};
R.info = () => ({ ok: !!gl, gpu: R.gpuName, float: FLOAT_OK, maxTex: R.maxTex, error: R.glError });
if (!ok) console.warn('GPU engine unavailable:', R.glError);
})();
