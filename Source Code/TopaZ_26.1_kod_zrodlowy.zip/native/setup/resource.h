#define IDR_LOGO 101
